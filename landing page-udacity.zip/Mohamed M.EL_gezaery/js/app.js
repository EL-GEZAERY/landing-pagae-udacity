

//  * Define Global Variables
// creation of document fragment
const fragment = document.createDocumentFragment()
// select all sections available by class name
const sections = document.querySelectorAll('section')
// select ul element by id
const ulSelection = document.getElementById('navbar__list')
//  * End Global Variables


//  ***************************************************************************************************


///*************************** */ build the nav*********************************
// initiallizing counter
let count1 = 1
// looping sections
for (const section of sections) {
    // creating list elements
    const nav = document.createElement('li')
    nav.textContent = 'section ' + count1
    // creating anchor element to navigate to selected section
    nav.innerHTML = `<a href=#section${+count1} class='menu__link'>Section ${+count1}</a>`
    // append the navbar into fragment
    fragment.appendChild(nav)
    // increment counter by one
    count1++
}
// append fragment in the ul element
ulSelection.appendChild(fragment)

// *********************************************************************************************

//*********************** */ event listner when clicking the link to make smooth scroll******************
document.addEventListener('click', smoothView);
//  function of smoothView
function smoothView(event) {
    // preventing default action
    event.preventDefault()
    // getting ref of link 
    let ref = event.target.getAttribute("href");
    // remove the hash
    ref = ref.substring(1)
    // getting wanted section to be scrolled
    const wantedSec = document.getElementById(`${ref}`)
    wantedSec.scrollIntoView({
        behavior: 'smooth',

    })
}

// *********************************************************************************


// ***********make section and correspondive link active**********
// Add class 'active' to section when near top of viewport
function makeActive() {
    // initiallize counter
    let count2 = -1
    // select all anchors
    const anchors = document.querySelectorAll('a.menu__link')
    // loop over sections
    for (const section of sections) {
        // increment counter
        count2++
        // make a variable that store the dimensions of sections
        const dimensions = section.getBoundingClientRect()
        // if section in view => do the following
        if (dimensions.top <= 100 && dimensions.bottom >= 200) {
            // add active class to the viewed section
            section.classList.add('your-active-class')
            // select all elements with active class
            const active = document.querySelector('.your-active-class').getAttribute('data-nav')
            //    test 
            // console.log('active section: ' + active)
            //    test 
            // console.log('active anchor: ' + anchors[count2].textContent)
            // if viewed section tittle equal to nav bar title => do the following
            if (anchors[count2].textContent === active) {
                // add link-is-active class to the specified anchor
                anchors[count2].classList.add('link-is-active')
            }

        }
        else {
            // remove your-active-class from section's class
            section.classList.remove('your-active-class')
            // remove link-is-active from specified anchor
            anchors[count2].classList.remove('link-is-active')

        }
    }

}
document.addEventListener('scroll', makeActive);

// ********************************************************************************


// ************responsive nav************
// hahah! counter again!, for me counter is a problem solver
// i used counter here to make the humburger icon disappear whenever i use an odd number of clicking!
let count3 = 0
const icon = document.querySelector('.hamburger__icon')
icon.addEventListener('click', activate)
const navbarMenu = document.querySelector('.navbar__menu')
function activate() {
    // adding active class whenever i click on the humberger icon
    navbarMenu.classList.add('active')
    // chcking is number of clicking even or odd *if odd remove the active class to stop displaying the list*
    if (count3 % 2 !== 0)
        // removing active class
        navbarMenu.classList.remove('active')
    // increment counter whenever i click the icon
    count3++
}




