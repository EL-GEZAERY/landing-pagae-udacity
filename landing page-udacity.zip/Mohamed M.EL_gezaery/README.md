# Landing Page Project

## Table of Contents:
1-project title *landing page*.
2-sections.
3-responsive nav menu *having specific number of links*.
4-footer.


* [Instructions](#instructions)

## features:
1-corresponding links gets highlighted when a specific section is viewed in the view port
2-responsive nav bar
3-humberger icon when the view port max-width is 600px
4-when clicking the icon it display a list of links

## methods:
### js:
. createDocumentFragment()
. querySelectorAll()
. getElementById()
. addEventListener()
. preventDefault
. substring()
. scrollIntoView()
. createElement()
. appendChild()
. getBoundingClientRect()
. classList.add()
. classList.remove()
. querySelector()
### css:
. @media screen and ()